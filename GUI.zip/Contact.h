#ifndef CONTACT_H
#define CONTACT_H

#include <QListWidgetItem>
#include <QList>
#include <QDate>
#include <QMap>


class Contact{
public:
    //QList<QString> names;

    QMap<QString, QDate> contacts;

    QDate date;
    void operator =(const Contact& t);
};

#endif // CONTACT_H
