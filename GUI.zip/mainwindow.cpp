#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QListWidgetItem>
#include <QListWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QInputDialog>
#include <QDir>
#include <QLabel>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::loadFile(QString filename){
    QFile file(filename);

    if (!file.open(QFile::ReadOnly)){
        QMessageBox::critical(this, "Hiba", "A file nem megfelelő");
    }

    QTextStream stream(&file);
    stream.setCodec("UTF-8");
    QString line;

    while(stream.readLineInto(&line)){
        ui->listWidget->addItem(line);
    }

    file.close();
}

void Contact::operator=(const Contact & c){
    date = c.date;
    //names = c.names;!!!
    contacts = c.contacts;
}

void MainWindow::on_pushButtonNames_clicked()
{
    ui->listWidget->addItem(ui->lineEdit->text());
}

void MainWindow::on_pushButtonContacts_clicked()
{
    contact.date = ui->dateEdit->date();
    for(QListWidgetItem * it: ui->listWidget->selectedItems()){
        contact.contacts[it->text()] = contact.date;
    }

    QStringList strings;
    foreach( QListWidgetItem *item, ui->listWidget->selectedItems() )
        strings << item->text();

    for(int i = 0; i < strings.size(); ++i){
        ui->itemList->addItem(strings.at(i) + ": " + contact.date.toString());
    }
}

void MainWindow::on_pushButtonDelete_clicked()
{
    qDeleteAll(ui->listWidget->selectedItems());
}



void MainWindow::on_DeleteContact_clicked()
{
    qDeleteAll(ui->itemList->selectedItems());
}

void MainWindow::on_actionNevek_hozz_ad_sa_f_jlb_l_triggered()
{
    QString filter = "Txt files (*.txt) ;; All file (*.*)";
    QString filename = QFileDialog::getOpenFileName(this, "Válaszd ki a fájlt", "C:/", filter);
    if (filename != "") {
        loadFile(filename);
    }
}

void MainWindow::on_actionKontaktfelh_lek_r_se_triggered()
{
    QString date_time = QInputDialog::getText(this, tr("Kontaktfelhő lekérése"), tr("Időpont (Pl.: Szo jan. 1 2000):"));
    //int date_interval = QInputDialog::getInt(this, tr("Kontaktfelhő lekérése"), tr("Idősáv (nap):"));
    ui->itemList->clear();

    QMapIterator<QString, QDate> it(contact.contacts);
    while(it.hasNext()){
        it.next();
        if(it.value().toString() == date_time){
            ui->label->setText(it.value().toString() + " időpontban lévő kontaktok:");
            ui->itemList->addItem(it.key());
        }
    }
}

void MainWindow::on_actionTeljes_kontaktlista_ki_r_sa_triggered()
{
    ui->itemList->clear();
    QMapIterator<QString, QDate> it(contact.contacts);
    while(it.hasNext()){
        it.next();
        ui->itemList->addItem(it.key() + ", " + it.value().toString());
    }
}
