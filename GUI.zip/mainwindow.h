#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "Contact.h"
#include <QMainWindow>
#include <QVector>
#include <QDate>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButtonNames_clicked();

    void on_pushButtonContacts_clicked();

    void on_pushButtonDelete_clicked();

    void on_DeleteContact_clicked();

    void on_actionNevek_hozz_ad_sa_f_jlb_l_triggered();

    void on_actionKontaktfelh_lek_r_se_triggered();

    void on_actionTeljes_kontaktlista_ki_r_sa_triggered();

private:
    Ui::MainWindow *ui;
    Contact contact;

    void loadFile(QString filename);
};
#endif // MAINWINDOW_H
